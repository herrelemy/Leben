# Deutsch Abou Ghalia — Fragewörter & Personalpronomen

درس تفاعلي كامل (PWA) لطلاب أولى ثانوي: أدوات الاستفهام + الضمائر الشخصية + تصريف الأفعال.
Plain HTML/CSS/JS — no framework, no bundler required. `npm run build` just copies
`public/` into `dist/`, which is what Netlify publishes.

## Project structure

```
.
├── public/                 # source files (edit these)
│   ├── index.html
│   ├── manifest.json
│   ├── service-worker.js
│   └── icons/
│       ├── icon-192.png
│       └── icon-512.png
├── build.js                # copies public/ -> dist/
├── package.json
├── netlify.toml             # build command + publish dir + cache headers
└── dist/                    # generated on build — do not edit, do not commit
```

## Run locally

```bash
npm run dev
```

Opens the site straight from `public/` at http://localhost:5000 (no build step, fastest for editing).

To test the actual production build (what Netlify will serve):

```bash
npm run build
npm start
```

## Deploy on Netlify

**Build command:** `npm run build`
**Publish directory:** `dist`

### Option A — Netlify UI (drag & drop, no Git needed)
1. Run `npm run build` locally so a `dist/` folder exists.
2. Go to https://app.netlify.com/drop
3. Drag the `dist/` folder in. Netlify gives you a live URL immediately.

### Option B — Connect a Git repo (recommended for future edits)
1. Push this whole folder to a GitHub repo.
2. In Netlify: **Add new site → Import an existing project** → pick the repo.
3. Netlify reads `netlify.toml` automatically, so Build command and Publish
   directory are pre-filled (`npm run build` / `dist`) — just click **Deploy**.
4. Every future `git push` redeploys automatically.

## Installing it as an app (PWA)

Once deployed to an `https://` URL:
1. Open the Netlify link on a phone (Chrome or Safari).
2. Tap **Add to Home Screen**.
3. It opens full-screen with its own icon, and works offline after the first visit
   (the service worker caches `index.html`, `manifest.json`, and the icons).

## Editing content

All lesson content, styling, and logic live in `public/index.html` (self-contained —
no separate CSS/JS files). Edit it, then re-run `npm run build` (or just push to Git
if using Option B) to publish the changes.
