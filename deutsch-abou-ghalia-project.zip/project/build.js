/**
 * Build script for Deutsch Abou Ghalia — Fragewörter & Personalpronomen
 * This is a static site (plain HTML/CSS/JS, no framework), so "building" it
 * just means copying /public into /dist, the folder Netlify publishes.
 * Kept as a real script (not a no-op) so the project has a normal
 * npm run build -> deploy folder workflow, and so future assets
 * (new pages, more lessons) can be added to public/ without changing this file.
 */
const fs = require("fs");
const path = require("path");

const SRC = path.join(__dirname, "public");
const OUT = path.join(__dirname, "dist");

function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.copyFileSync(src, dest);
  }
}

if (fs.existsSync(OUT)) {
  fs.rmSync(OUT, { recursive: true, force: true });
}

copyRecursive(SRC, OUT);

console.log(`✔ Build complete: ${SRC} -> ${OUT}`);
